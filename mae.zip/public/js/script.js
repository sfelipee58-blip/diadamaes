let treeData = null;
let activeNodeId = null;

document.addEventListener('DOMContentLoaded', () => {
    fetchTreeData();
    initParticles();
    initAdmin();
    initConstellation();
    window.addEventListener('resize', drawConnections);

    // Splash Screen Logic
    const splash = document.getElementById('welcome-splash');
    const startBtn = document.getElementById('start-btn');
    if (startBtn) {
        startBtn.addEventListener('click', () => {
            splash.classList.add('hidden');
            // Explosão inicial de confete
            if (typeof confetti === 'function') {
                setTimeout(() => {
                    confetti({
                        particleCount: 250,
                        spread: 120,
                        origin: { y: 0.6 },
                        colors: ['#00d2ff', '#3b82f6', '#ffffff', '#db2777']
                    });
                }, 400);
            }
        });
    }
});


function initConstellation() {
    const canvas = document.getElementById('constellation-canvas');
    const ctx = canvas.getContext('2d');
    let points = [];
    const maxPoints = 120;
    const connectionDistance = 160;

    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }

    class Point {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.vx = (Math.random() - 0.5) * 0.5;
            this.vy = (Math.random() - 0.5) * 0.5;
            this.radius = Math.random() * 2 + 1;
        }

        update() {
            this.x += this.vx;
            this.y += this.vy;

            if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
            if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
        }

        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
            ctx.fillStyle = 'rgba(0, 210, 255, 0.6)';
            ctx.fill();
        }
    }

    function init() {
        resize();
        points = [];
        for (let i = 0; i < maxPoints; i++) {
            points.push(new Point());
        }
    }

    function animate() {
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        points.forEach(p => {
            p.update();
            p.draw();
        });

        for (let i = 0; i < points.length; i++) {
            for (let j = i + 1; j < points.length; j++) {
                const dx = points[i].x - points[j].x;
                const dy = points[i].y - points[j].y;
                const distance = Math.sqrt(dx * dx + dy * dy);

                if (distance < connectionDistance) {
                    ctx.beginPath();
                    ctx.moveTo(points[i].x, points[i].y);
                    ctx.lineTo(points[j].x, points[j].y);
                    const opacity = 1 - (distance / connectionDistance);
                    ctx.strokeStyle = `rgba(0, 210, 255, ${opacity * 0.3})`;
                    ctx.lineWidth = 0.8;
                    ctx.stroke();
                }
            }
        }
        requestAnimationFrame(animate);
    }

    window.addEventListener('resize', init);
    init();
    animate();
}

async function fetchTreeData() {
    const res = await fetch('/api/tree');
    treeData = await res.json();
    
    document.getElementById('editable-title').innerText = treeData.title || "Nossas Raízes, Seu Amor";
    document.getElementById('editable-subtitle').innerText = treeData.subtitle || "Uma homenagem à mulher que é o tronco da nossa história.";
    
    renderTree();
}

function renderTree() {
    const root = document.getElementById('tree-root');
    root.innerHTML = '';
    
    const buildNodeHtml = (node) => {
        let childrenHtml = '';
        if (node.children && node.children.length > 0) {
            childrenHtml = `<ul>${node.children.map(child => `<li>${buildNodeHtml(child)}</li>`).join('')}</ul>`;
        }

        return `
            <div class="node-wrapper">
                <div class="node" data-id="${node.id}">
                    <div class="photo-frame" style="background-image: url('${node.img}')"></div>
                    <div class="info">
                        <h3>${node.title}</h3>
                        <p>${node.quote}</p>
                    </div>
                    <div class="node-actions admin-only">
                        <button class="action-btn add-child-btn" onclick="event.stopPropagation(); addChild('${node.id}')" title="Adicionar Filho">+</button>
                        ${node.id !== 'mom' ? `<button class="action-btn delete-node-btn" onclick="event.stopPropagation(); deleteNode('${node.id}')" title="Excluir">x</button>` : ''}
                    </div>
                </div>
            </div>
            ${childrenHtml}
        `;
    };

    root.innerHTML = `<ul><li>${buildNodeHtml(treeData.nodes[0])}</li></ul>`;
    
    attachNodeListeners();
    // Redesenhar conexões após renderizar
    setTimeout(drawConnections, 100);
}

function attachNodeListeners() {
    const nodes = document.querySelectorAll('.node');
    nodes.forEach(node => {
        node.addEventListener('click', (e) => {
            if (document.body.classList.contains('admin-mode')) {
                openEditPanel(node.getAttribute('data-id'));
            } else {
                openOverlay(node);
            }
        });
    });
}

function drawConnections() {
    const svg = document.getElementById('tree-connections');
    if (!svg) return;
    svg.innerHTML = '';
    
    const container = document.querySelector('.tree-container');
    const rect = container.getBoundingClientRect();
    svg.setAttribute('width', container.scrollWidth);
    svg.setAttribute('height', container.scrollHeight);

    const nodes = document.querySelectorAll('.node');
    nodes.forEach(node => {
        const li = node.closest('li');
        const parentUl = li.parentElement;
        const parentLi = parentUl.closest('li');
        
        if (parentLi) {
            const parentNode = parentLi.querySelector('.node');
            if (parentNode) {
                const start = parentNode.getBoundingClientRect();
                const end = node.getBoundingClientRect();
                
                const x1 = (start.left + start.width / 2) - rect.left + container.scrollLeft;
                const y1 = (start.bottom - 10) - rect.top + container.scrollTop;
                const x2 = (end.left + end.width / 2) - rect.left + container.scrollLeft;
                const y2 = (end.top + 10) - rect.top + container.scrollTop;
                
                const line = document.createElementNS('http://www.w3.org/2000/svg', 'line');
                line.setAttribute('x1', x1);
                line.setAttribute('y1', y1);
                line.setAttribute('x2', x2);
                line.setAttribute('y2', y2);
                line.setAttribute('class', 'tree-line');
                svg.appendChild(line);

                // Pontinho de brilho na junção
                const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
                circle.setAttribute('cx', x2);
                circle.setAttribute('cy', y2 - 5);
                circle.setAttribute('r', '2.5');
                circle.setAttribute('fill', '#00d2ff');
                circle.setAttribute('style', 'filter: drop-shadow(0 0 5px #00d2ff)');
                svg.appendChild(circle);
            }
        }
    });
}

function openOverlay(node) {
    const overlay = document.getElementById('photo-overlay');
    const overlayImg = document.getElementById('overlay-img');
    const overlayCaption = document.getElementById('overlay-caption');
    
    const bgImage = node.querySelector('.photo-frame').style.backgroundImage;
    const imgSrc = bgImage.replace(/url\(['"]?(.*?)['"]?\)/, '$1');
    const title = node.querySelector('h3').innerText;
    const quote = node.querySelector('p').innerText;

    overlayImg.src = imgSrc;
    overlayCaption.innerHTML = `<strong>${title}</strong><br>${quote}`;
    overlay.style.display = 'flex';
}

function initAdmin() {
    const adminBtn = document.getElementById('admin-mode-btn');
    const title = document.getElementById('editable-title');
    const subtitle = document.getElementById('editable-subtitle');

    adminBtn.addEventListener('click', () => {
        const isAdmin = document.body.classList.toggle('admin-mode');
        adminBtn.innerHTML = isAdmin ? '<i class="fas fa-unlock"></i>' : '<i class="fas fa-lock"></i>';
        title.contentEditable = isAdmin;
        subtitle.contentEditable = isAdmin;
    });

    document.getElementById('close-panel-btn').addEventListener('click', () => {
        document.getElementById('edit-panel').style.display = 'none';
    });

    document.getElementById('save-node-btn').addEventListener('click', saveNodeChanges);
}

function openEditPanel(nodeId) {
    activeNodeId = nodeId;
    const node = findNodeById(treeData.nodes[0], nodeId);
    
    document.getElementById('node-title-input').value = node.title;
    document.getElementById('node-quote-input').value = node.quote;
    document.getElementById('node-link-input').value = node.img.startsWith('http') ? node.img : '';
    document.getElementById('node-photo-input').value = '';
    document.getElementById('edit-panel').style.display = 'flex';
}

function findNodeById(rootNode, id) {
    if (rootNode.id === id) return rootNode;
    if (rootNode.children) {
        for (let child of rootNode.children) {
            const found = findNodeById(child, id);
            if (found) return found;
        }
    }
    return null;
}

async function saveNodeChanges() {
    const node = findNodeById(treeData.nodes[0], activeNodeId);
    const photoInput = document.getElementById('node-photo-input');
    const linkInput = document.getElementById('node-link-input');
    
    const saveBtn = document.getElementById('save-node-btn');
    const originalText = saveBtn.innerText;
    saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Salvando...';

    if (photoInput.files.length > 0) {
        const formData = new FormData();
        formData.append('photo', photoInput.files[0]);
        const uploadRes = await fetch('/api/upload', { method: 'POST', body: formData });
        const uploadData = await uploadRes.json();
        node.img = uploadData.url;
    } else if (linkInput.value.trim() !== '') {
        node.img = linkInput.value.trim();
    }

    node.title = document.getElementById('node-title-input').value;
    node.quote = document.getElementById('node-quote-input').value;
    treeData.title = document.getElementById('editable-title').innerText;
    treeData.subtitle = document.getElementById('editable-subtitle').innerText;

    await fetch('/api/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(treeData)
    });

    document.getElementById('edit-panel').style.display = 'none';
    saveBtn.innerText = originalText;
    
    renderTree();
    
    if (typeof confetti === 'function') {
        confetti({
            particleCount: 150,
            spread: 70,
            origin: { y: 0.6 },
            colors: ['#00d2ff', '#3b82f6', '#ffffff']
        });
    }
}

function addChild(parentId) {
    const parent = findNodeById(treeData.nodes[0], parentId);
    if (!parent) return;
    if (!parent.children) parent.children = [];
    
    const newNode = {
        id: 'node-' + Date.now(),
        title: 'Novo Membro',
        quote: 'Clique para editar...',
        img: 'assets/default_avatar.png',
        children: []
    };

    parent.children.push(newNode);
    renderTree();
    openEditPanel(newNode.id);
}

function deleteNode(id) {
    if (id === 'mom') return;
    if (!confirm('Remover este membro?')) return;

    const removeRecursive = (rootNode, targetId) => {
        if (!rootNode.children) return false;
        const index = rootNode.children.findIndex(child => child.id === targetId);
        if (index !== -1) {
            rootNode.children.splice(index, 1);
            return true;
        }
        for (let child of rootNode.children) {
            if (removeRecursive(child, targetId)) return true;
        }
        return false;
    };

    removeRecursive(treeData.nodes[0], id);
    renderTree();
    saveNodeChanges(); 
}

function initParticles() {
    const container = document.getElementById('particles-container');
    container.innerHTML = '';
    for (let i = 0; i < 40; i++) {
        const sparkle = document.createElement('div');
        sparkle.className = 'sparkle';
        sparkle.style.left = Math.random() * 100 + 'vw';
        sparkle.style.animationDelay = Math.random() * 10 + 's';
        sparkle.style.width = sparkle.style.height = Math.random() * 4 + 1 + 'px';
        container.appendChild(sparkle);
    }
}

document.getElementById('photo-overlay').onclick = () => document.getElementById('photo-overlay').style.display = 'none';

