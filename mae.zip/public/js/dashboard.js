document.addEventListener('DOMContentLoaded', () => {
    // 1. Animated Counters
    const counters = document.querySelectorAll('.counter');
    const speed = 200;

    counters.forEach(counter => {
        const updateCount = () => {
            const target = +counter.getAttribute('data-target');
            const count = +counter.innerText;
            const inc = target / speed;

            if (count < target) {
                counter.innerText = Math.ceil(count + inc);
                setTimeout(updateCount, 1);
            } else {
                counter.innerText = target.toLocaleString();
            }
        };
        updateCount();
    });

    // 2. Chart Initialization
    const ctx = document.getElementById('affectionChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['2020', '2021', '2022', '2023', '2024', '2025', '2026'],
            datasets: [{
                label: 'Nível de Amor (TB)',
                data: [100, 250, 480, 720, 1100, 1500, 2500],
                borderColor: '#f472b6',
                backgroundColor: 'rgba(244, 114, 182, 0.1)',
                borderWidth: 3,
                tension: 0.4,
                fill: true,
                pointBackgroundColor: '#f472b6',
                pointRadius: 5
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: { display: false },
                x: {
                    grid: { display: false },
                    ticks: { color: '#94a3b8' }
                }
            }
        }
    });

    // 3. Profile Photo Upload
    const profileUpload = document.getElementById('profile-upload');
    const profilePreview = document.getElementById('profile-img-preview');

    profilePreview.addEventListener('click', () => profileUpload.click());

    profileUpload.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                profilePreview.style.backgroundImage = `url(${e.target.result})`;
            }
            reader.readAsDataURL(file);
        }
    });

    // 4. Gallery Upload
    const galleryUpload = document.getElementById('gallery-upload');
    const galleryContainer = document.getElementById('gallery-container');

    galleryUpload.addEventListener('change', function() {
        const files = this.files;
        for (let file of files) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const item = document.createElement('div');
                item.className = 'gallery-item';
                item.style.backgroundImage = `url(${e.target.result})`;
                galleryContainer.prepend(item);
            }
            reader.readAsDataURL(file);
        }
    });

    // 5. Save Button Interaction
    const saveBtn = document.querySelector('.save-btn');
    saveBtn.addEventListener('click', () => {
        saveBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sincronizando...';
        
        // Simulating a surreal save effect
        setTimeout(() => {
            saveBtn.innerHTML = '<i class="fas fa-check"></i> Dashboard Atualizado!';
            saveBtn.style.background = '#4ade80';
            
            // Trigger confetti
            if (typeof confetti === 'function') {
                confetti({
                    particleCount: 100,
                    spread: 70,
                    origin: { y: 0.6 }
                });
            }

            setTimeout(() => {
                saveBtn.innerHTML = '<i class="fas fa-cloud-upload-alt"></i> Salvar Alterações';
                saveBtn.style.background = 'var(--accent-pink)';
            }, 3000);
        }, 1500);
    });

    // Optional: Confetti library dynamic loading if needed (but we used CDN in head if present)
});
